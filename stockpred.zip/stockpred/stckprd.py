from flask import Flask, url_for, render_template
from markupsafe import escape
from flask import request
app = Flask(__name__)

#@app.route('/login', methods=['GET', 'POST'])
#def login():
#    if request.method == 'POST':
#        return do_the_login()
#    else:
#        return show_the_login_form()

#def show_the_login_form():
#    return render_template('loginForm.html', name=name)
@app.route('/hello')
@app.route('/hello/<name>')
def login(name=None):
    return render_template('loginForm.html', name=name)


@app.route('/stckprd')
def index():
    return render_template('mainMenu.html')

@app.route('/stockinfo')
def info():
    return render_template('stockInfo.html')

@app.route('/predsandrecs')
def predictions():
    return render_template('predictions.html')

@app.route('/visuals')
def visualisations():
    return render_template('visualisations.html')
